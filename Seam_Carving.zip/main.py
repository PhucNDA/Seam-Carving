import numpy as np
import cv2
from scipy import ndimage as ndi 
from numba import jit 
import SeamCarving as SC

def main():
    img=cv2.imread('img/balloon.jpg')
    h,w,c=img.shape
    originalShape=img.shape
    mask1=cv2.imread('mask/balloon_pro.png',0)
    mask2=cv2.imread('mask/balloon_del.png',0)
    img=SC.removeObjectfromMask(img,objectMaskProtect=mask1,objectMaskDelete=mask2)
    cv2.imwrite('Carved_Image.jpg',img)
    revertSize((h,w,c),img)
    SC.produceVideo('out_result.gif',originalShape)


def revertSize(originalShape, curImage):
    h,w,c=originalShape
    print(curImage.shape)
    hs,ws,cs=curImage.shape
    curImage=SC.enlargeImage(curImage,w-ws)
    cv2.imwrite('Final_Image.jpg',curImage)

if __name__ == "__main__":
    main()